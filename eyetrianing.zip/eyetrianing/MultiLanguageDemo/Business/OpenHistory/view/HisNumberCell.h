//
//  HisNumberCell.h
//  MultiLanguageDemo
//
//  Created by 朱松泽 on 2018/3/17.
//  Copyright © 2018年 朱松泽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HisNumberCell : UICollectionViewCell
@property (nonatomic, strong) UILabel *numberLab;
@end
