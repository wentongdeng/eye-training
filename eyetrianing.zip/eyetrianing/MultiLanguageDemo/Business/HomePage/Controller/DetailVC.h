//
//  DetailVC.h
//  MultiLanguageDemo
//
//  Created by 朱松泽 on 2018/3/17.
//  Copyright © 2018年 朱松泽. All rights reserved.
//

#import "ZSZViewController.h"
#import "HPListModel.h"
@interface DetailVC : ZSZViewController
@property (nonatomic, strong) HPListModel *myModel;
@end
