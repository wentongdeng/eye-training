//
//  HPListCell.h
//  MultiLanguageDemo
//
//  Created by 朱松泽 on 2018/3/16.
//  Copyright © 2018年 朱松泽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HPListCell : UITableViewCell
@property (nonatomic, strong) UIImageView *myImageView;
@property (nonatomic, strong) UILabel *topLab;
@property (nonatomic, strong) UILabel *bottomLab;
@end
