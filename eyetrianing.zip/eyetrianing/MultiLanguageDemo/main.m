//
//  main.m
//  MultiLanguageDemo
//
//  Created by 朱松泽 on 2018/3/15.
//  Copyright © 2018年 朱松泽. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
