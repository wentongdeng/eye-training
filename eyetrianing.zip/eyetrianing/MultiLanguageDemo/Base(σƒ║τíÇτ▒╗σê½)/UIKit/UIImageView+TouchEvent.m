//
//  UIImageView+TouchEvent.m
//  yxx_ios
//
//  Created by victor siu on 17/3/29.
//  Copyright © 2017年 GDtech. All rights reserved.
//

#import "UIImageView+TouchEvent.h"

@implementation UIImageView (TouchEvent)

//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    [[self nextResponder] touchesBegan:touches withEvent:event];
//    [super touchesBegan:touches withEvent:event];
//}
//
//- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
//{
//    [[self nextResponder] touchesMoved:touches withEvent:event];
//    [super touchesMoved:touches withEvent:event];
//}
//
//- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
//{
//    [[self nextResponder] touchesEnded:touches withEvent:event];
//    [super touchesEnded:touches withEvent:event];
//}
//
//- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
//{
//    [[self nextResponder] touchesCancelled:touches withEvent:event];
//    [super touchesCancelled:touches withEvent:event];
//}
@end
