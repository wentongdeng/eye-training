//
//  UIView+UITableViewCell.h
//  yxx_ios
//
//  Created by victor siu on 17/3/23.
//  Copyright © 2017年 GDtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (UITableViewCell)

@property (nullable, nonatomic, weak) UITableViewCell *tableViewCell;

@end
