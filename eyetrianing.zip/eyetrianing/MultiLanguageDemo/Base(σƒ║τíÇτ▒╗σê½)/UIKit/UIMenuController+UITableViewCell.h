//
//  UIMenuController+UITableViewCell.h
//  yxx_ios
//
//  Created by victor siu on 17/4/5.
//  Copyright © 2017年 GDtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIMenuController (UITableViewCell)

@property (nullable, nonatomic, weak) UITableViewCell *tableViewCell;

@end
