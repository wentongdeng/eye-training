//
//  UIImageView+TouchEvent.h
//  yxx_ios
//
//  Created by victor siu on 17/3/29.
//  Copyright © 2017年 GDtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (TouchEvent)

@end
