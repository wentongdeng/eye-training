//
//  NSString+ZSZFileSize.h
//  FunSDKDemo
//
//  Created by 朱松泽 on 2018/1/4.
//  Copyright © 2018年 xiongmaitech. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ZSZFileSize)
- (unsigned long long)fileSize;
@end
