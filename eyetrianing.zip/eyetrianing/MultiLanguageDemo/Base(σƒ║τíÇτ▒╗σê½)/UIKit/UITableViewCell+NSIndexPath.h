//
//  UITableViewCell+NSIndexPath.h
//  yxx_ios
//
//  Created by yuan on 2017/4/15.
//  Copyright © 2017年 GDtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (NSIndexPath)

@property (nonatomic, copy) NSIndexPath *indexPath;

@end
