//
//  ImageFullScreenView.h
//  FunSDKDemo
//
//  Created by 朱松泽 on 2017/12/16.
//  Copyright © 2017年 xiongmaitech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageFullScreenView : UIView
@property (nonatomic, strong) UIImageView *myImageView;
@property (nonatomic, strong) UIScrollView *myScrollView;
@end
