//
//  UIColor+colorToImage.h
//  sdxt
//
//  Created by 朱松泽 on 2017/11/13.
//  Copyright © 2017年 com.gdtech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (colorToImage)
+ (UIImage *)imageWithColor:(UIColor *)color;
@end
